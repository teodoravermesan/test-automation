package pages;
import org.openqa.selenium.*;
import org.openqa.selenium.support.FindBy;

public class ItemPage extends BasePage {
    public ItemPage(WebDriver driver) { super(driver); }

    @FindBy(id = "itemName") WebElement itemName;
    @FindBy(id = "saveBtn") WebElement saveButton;

    public void createItem(String name) {
        itemName.sendKeys(name);
        saveButton.click();
    }

    public void editItem(String oldName, String newName) {
        driver.findElement(By.xpath("//td[text()='" + oldName + "']/..//button[text()='Edit']")).click();
        WebElement input = driver.findElement(By.id("itemName"));
        input.clear();
        input.sendKeys(newName);
        saveButton.click();
    }

    public void deleteItem(String name) {
        driver.findElement(By.xpath("//td[text()='" + name + "']/..//button[text()='Delete']")).click();
        driver.switchTo().alert().accept();
    }

    public boolean isItemPresent(String name) {
        return driver.findElements(By.xpath("//td[text()='" + name + "']")).size() > 0;
    }
}