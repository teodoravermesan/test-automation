package tests;
import base.TestBase;
import pages.ItemPage;
import pages.LoginPage;
import org.testng.Assert;
import org.testng.annotations.Test;

public class ItemTests extends TestBase {

    @Test(priority = 1)
    public void createItemTest() {
        new LoginPage(driver).login("validUser", "validPass");
        driver.get("https://yourappurl.com/items/new");
        ItemPage itemPage = new ItemPage(driver);
        itemPage.createItem("TestItem");
        Assert.assertTrue(itemPage.isItemPresent("TestItem"));
    }

    @Test(priority = 2)
    public void editItemTest() {
        ItemPage itemPage = new ItemPage(driver);
        itemPage.editItem("TestItem", "UpdatedItem");
        Assert.assertTrue(itemPage.isItemPresent("UpdatedItem"));
    }

    @Test(priority = 3)
    public void deleteItemTest() {
        ItemPage itemPage = new ItemPage(driver);
        itemPage.deleteItem("UpdatedItem");
        Assert.assertFalse(itemPage.isItemPresent("UpdatedItem"));
    }
}