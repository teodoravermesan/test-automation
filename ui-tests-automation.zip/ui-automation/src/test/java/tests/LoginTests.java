package tests;
import base.TestBase;
import pages.LoginPage;
import org.testng.Assert;
import org.testng.annotations.Test;

public class LoginTests extends TestBase {
    @Test
    public void validLogin() {
        LoginPage login = new LoginPage(driver);
        login.login("validUser", "validPass");
        Assert.assertTrue(driver.getCurrentUrl().contains("dashboard"));
    }

    @Test
    public void invalidLogin() {
        LoginPage login = new LoginPage(driver);
        login.login("invalid", "wrong");
        Assert.assertTrue(login.isErrorDisplayed());
    }
}